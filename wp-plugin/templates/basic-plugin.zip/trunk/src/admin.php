<?php

/**
* @package AuthorNameX_PLUGIN_NAME_X
*/

if (!defined('ABSPATH')) {
  http_response_code(404);
  die('404 Not Found');
}

if (!class_exists('AuthorName_X_PLUGIN_NAME_X_Admin')) {

  class AuthorName_X_PLUGIN_NAME_X_Admin {

    public $plugin;
    private static $func;
    private static $options;

    public function init($pluginData) {
      // get plugin data and load common functions
      $this->plugin = $pluginData;
      self::$func = $this->plugin['func'];
      self::$options = $this->plugin['options'];
    }

    public function start() {
      // do stuff on backend
    }
  }

  $authorName_X_PLUGIN_NAME_X_Admin = new AuthorName_X_PLUGIN_NAME_X_Admin();
}
