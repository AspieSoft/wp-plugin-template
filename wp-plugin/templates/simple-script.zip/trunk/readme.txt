=== AuthorName X_PLUGIN_DISPLAY_NAME_X ===
Contributors: AuthorName
Tags: AuthorName, plugin, template
Requires at least: 3.0.1
Tested up to: 5.8
Stable tag: X_PLUGIN_VERSION_STRICT_X
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://donate.example.com

== Description ==
Plugin Description

== Installation ==

1. Upload plugin to the /wp-content/plugins
2. Activate the plugin through the "Plugins" menu in WordPress
3. Enjoy

== Frequently Asked Questions ==

= How do I use the shortcode? =
[X_PLUGIN_SLUG_X
  attr="value example or description"
]

= Question 1? =
Answer 1

= Question 2? =
Answer 2

== Changelog ==

= 1.0 =
Initial Commit

== Upgrade Notice ==

= 1.0 =
Initial Commit
